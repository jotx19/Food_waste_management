package DTO;

public enum Types {
	Retailer,
	Consumer,
	Charity
}
